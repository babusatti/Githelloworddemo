#! /bin/bash
sudo yum update
sudo yum install -y httpd
sudo service httpd start
echo "<h1>Hello from IP Address "3.93.23.91"  </h1>" | sudo tee /var/www/html/index.html
